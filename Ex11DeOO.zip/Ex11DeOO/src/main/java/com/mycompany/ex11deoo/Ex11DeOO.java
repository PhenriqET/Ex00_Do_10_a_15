package com.mycompany.ex11deoo;

//NA PROXIMA FAZ UM GERENCIADOR DE CONTA E BANCO
public class Ex11DeOO {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
